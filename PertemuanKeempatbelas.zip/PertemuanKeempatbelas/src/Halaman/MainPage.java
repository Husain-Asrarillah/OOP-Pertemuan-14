/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Halaman;

import Entity.*;
import HalamanLogin.LoginPage;
import java.awt.*;
import java.util.List;
import javax.persistence.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import net.sf.jasperreports.engine.*;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;
import javax.swing.JOptionPane;

/**
 *
 * @author Husain
 */
public class MainPage extends javax.swing.JFrame {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PertemuanKeempatbelasPU");
    EntityManager em = emf.createEntityManager();

    /**
     * Creates new form MainPage
     */
    public MainPage() {
        setTitle("Aplikasi Manajemen Komik - Dashboard");
        setSize(1000, 700); // Agak diperbesar biar muat
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        initComponents1();
        loadDataKomik();
        loadDataPengarang();
        loadDataDetail();
    }

    private void initComponents1() {
        // HEADER
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(colorDark);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));

        JLabel lblTitle = new JLabel("<html><span style='color:white'>MANAJEMEN</span> <span style='color:#99CCFF'>KOMIK</span></html>");
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 28));

        btnLogout = new JButton("LOGOUT");
        styleButton(btnLogout, Color.RED, Color.WHITE);
        btnLogout.setPreferredSize(new Dimension(120, 40));
        btnLogout.addActionListener(e -> {
            new LoginPage().setVisible(true);
            dispose();
        });

        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(btnLogout, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // TABBED PANE
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Times New Roman", Font.BOLD, 14));

        tabbedPane.addTab("Data Komik", createTabKomik());
        tabbedPane.addTab("Data Pengarang", createTabPengarang());
        tabbedPane.addTab("Detail Karya", createTabDetail());

        add(tabbedPane, BorderLayout.CENTER);

        tabbedPane.addChangeListener(e -> {
            int index = tabbedPane.getSelectedIndex();
            if (index == 0) {
                loadDataKomik();
            }
            if (index == 1) {
                loadDataPengarang();
            }
            if (index == 2) {
                loadDataDetail();
            }
        });
    }

    // =======================================================================
    // 1. CREATE TAB KOMIK (DENGAN 2 BARIS TOMBOL)
    // =======================================================================
    private JPanel createTabKomik() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(colorDark);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tabel
        tblKomik = new JTable();
        tblKomik.setRowHeight(30);
        JScrollPane scroll = new JScrollPane(tblKomik);
        panel.add(scroll, BorderLayout.CENTER);

        // --- PANEL TOMBOL (SOUTH) ---
        // Gunakan GridLayout 2 baris, 1 kolom
        JPanel mainSouth = new JPanel(new GridLayout(2, 1, 0, 10));
        mainSouth.setBackground(colorDark);

        // Baris 1: CRUD
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        row1.setBackground(colorDark);
        btnAddKomik = createButton("TAMBAH", colorBlue, colorText);
        btnEditKomik = createButton("EDIT", Color.ORANGE, Color.WHITE);
        btnDelKomik = createButton("HAPUS", Color.RED, Color.WHITE);
        row1.add(btnAddKomik);
        row1.add(btnEditKomik);
        row1.add(btnDelKomik);

        // Baris 2: TOOLS (Upload, Download, Print)
        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        row2.setBackground(colorDark);
        btnUpKomik = createButton("UPLOAD", colorExcel, Color.WHITE);
        btnDownKomik = createButton("DOWNLOAD", colorDL, Color.WHITE);
        btnPrintKomik = createButton("CETAK", colorPrint, Color.WHITE);
        row2.add(btnUpKomik);
        row2.add(btnDownKomik);
        row2.add(btnPrintKomik);

        mainSouth.add(row1);
        mainSouth.add(row2);
        panel.add(mainSouth, BorderLayout.SOUTH);

        // --- ACTIONS ---
        btnAddKomik.addActionListener(e -> {
            KomikDialog d = new KomikDialog(this, true, em, null);
            d.setVisible(true);
            if (d.isSucceeded()) {
                loadDataKomik();
            }
        });

        btnEditKomik.addActionListener(e -> {
            int row = tblKomik.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Pilih baris dulu!");
                return;
            }
            int id = Integer.parseInt(tblKomik.getValueAt(row, 0).toString());
            Komik k = em.find(Komik.class, id);
            KomikDialog d = new KomikDialog(this, true, em, k);
            d.setVisible(true);
            if (d.isSucceeded()) {
                loadDataKomik();
            }
        });

        btnDelKomik.addActionListener(e -> aksiHapusKomik());

        // Dummy Action untuk tombol baru
        btnUpKomik.addActionListener(e -> aksiUploadKomik());
        btnDownKomik.addActionListener(e -> aksiDownloadKomik());
        btnPrintKomik.addActionListener(e -> aksiCetakLaporan("Komik.jasper"));

        return panel;
    }

    // =======================================================================
    // 2. CREATE TAB PENGARANG
    // =======================================================================
    private JPanel createTabPengarang() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(colorDark);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        tblPengarang = new JTable();
        tblPengarang.setRowHeight(30);
        JScrollPane scroll = new JScrollPane(tblPengarang);
        panel.add(scroll, BorderLayout.CENTER);

        // Panel Tombol Bertingkat
        JPanel mainSouth = new JPanel(new GridLayout(2, 1, 0, 10));
        mainSouth.setBackground(colorDark);

        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        row1.setBackground(colorDark);
        btnAddPengarang = createButton("TAMBAH", colorBlue, colorText);
        btnEditPengarang = createButton("EDIT", Color.ORANGE, Color.WHITE);
        btnDelPengarang = createButton("HAPUS", Color.RED, Color.WHITE);
        row1.add(btnAddPengarang);
        row1.add(btnEditPengarang);
        row1.add(btnDelPengarang);

        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        row2.setBackground(colorDark);
        btnUpPengarang = createButton("UPLOAD", colorExcel, Color.WHITE);
        btnDownPengarang = createButton("DOWNLOAD", colorDL, Color.WHITE);
        btnPrintPengarang = createButton("CETAK", colorPrint, Color.WHITE);
        row2.add(btnUpPengarang);
        row2.add(btnDownPengarang);
        row2.add(btnPrintPengarang);

        mainSouth.add(row1);
        mainSouth.add(row2);
        panel.add(mainSouth, BorderLayout.SOUTH);

        // Actions
        btnAddPengarang.addActionListener(e -> {
            PengarangDialog d = new PengarangDialog(this, true, em, null);
            d.setVisible(true);
            if (d.isSucceeded()) {
                loadDataPengarang();
            }
        });

        btnEditPengarang.addActionListener(e -> {
            int row = tblPengarang.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Pilih baris dulu!");
                return;
            }
            int id = Integer.parseInt(tblPengarang.getValueAt(row, 0).toString());
            Pengarang p = em.find(Pengarang.class, id);
            PengarangDialog d = new PengarangDialog(this, true, em, p);
            d.setVisible(true);
            if (d.isSucceeded()) {
                loadDataPengarang();
            }
        });

        btnDelPengarang.addActionListener(e -> aksiHapusPengarang());

        // Dummy
        btnUpPengarang.addActionListener(e -> aksiUploadPengarang());
        btnDownPengarang.addActionListener(e -> aksiDownloadPengarang());
        btnPrintPengarang.addActionListener(e -> aksiCetakLaporan("Pengarang.jasper"));

        return panel;
    }

    // =======================================================================
    // 3. CREATE TAB DETAIL
    // =======================================================================
    private JPanel createTabDetail() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(colorDark);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        tblDetail = new JTable();
        tblDetail.setRowHeight(30);
        JScrollPane scroll = new JScrollPane(tblDetail);
        panel.add(scroll, BorderLayout.CENTER);

        // Panel Tombol Bertingkat
        JPanel mainSouth = new JPanel(new GridLayout(2, 1, 0, 10));
        mainSouth.setBackground(colorDark);

        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        row1.setBackground(colorDark);
        btnAddDetail = createButton("TAMBAH", colorBlue, colorText);
        btnEditDetail = createButton("EDIT", Color.ORANGE, Color.WHITE);
        btnDelDetail = createButton("HAPUS", Color.RED, Color.WHITE);
        row1.add(btnAddDetail);
        row1.add(btnEditDetail);
        row1.add(btnDelDetail);

        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        row2.setBackground(colorDark);
        btnUpDetail = createButton("UPLOAD", colorExcel, Color.WHITE);
        btnDownDetail = createButton("DOWNLOAD", colorDL, Color.WHITE);
        btnPrintDetail = createButton("CETAK", colorPrint, Color.WHITE);
        row2.add(btnUpDetail);
        row2.add(btnDownDetail);
        row2.add(btnPrintDetail);

        mainSouth.add(row1);
        mainSouth.add(row2);
        panel.add(mainSouth, BorderLayout.SOUTH);

        // Actions
        btnAddDetail.addActionListener(e -> {
            InputDetail d = new InputDetail(this, true, em, null);
            d.setVisible(true);
            if (d.isSucceeded()) {
                loadDataDetail();
            }
        });

        btnEditDetail.addActionListener(e -> {
            int row = tblDetail.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Pilih baris dulu!");
                return;
            }
            int id = Integer.parseInt(tblDetail.getValueAt(row, 0).toString());
            DetailKarya dk = em.find(DetailKarya.class, id);
            InputDetail d = new InputDetail(this, true, em, dk);
            d.setVisible(true);
            if (d.isSucceeded()) {
                loadDataDetail();
            }
        });

        btnDelDetail.addActionListener(e -> aksiHapusDetail());

        // Dummy
        btnUpDetail.addActionListener(e -> aksiUploadDetail());
        btnDownDetail.addActionListener(e -> aksiDownloadDetail());
        btnPrintDetail.addActionListener(e -> aksiCetakLaporan("DetailKarya.jasper"));

        return panel;
    }

    // Helper Create Button
    private JButton createButton(String text, Color bg, Color fg) {
        JButton b = new JButton(text);
        b.setPreferredSize(new Dimension(160, 40)); // Ukuran tombol sedikit dikecilkan biar muat
        styleButton(b, bg, fg);
        return b;
    }

    private void styleButton(JButton b, Color bg, Color fg) {
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFont(new Font("Times New Roman", Font.BOLD, 12));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // =======================================================================
    // 4. LOGIC LOAD DATA & HAPUS (Sama seperti sebelumnya)
    // =======================================================================

    private void loadDataKomik() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Judul", "Genre", "Tahun", "Harga"}, 0);
        List<Komik> list = em.createNamedQuery("Komik.findAll", Komik.class).getResultList();
        for (Komik k : list) {
            model.addRow(new Object[]{k.getKomikId(), k.getJudul(), k.getGenre(), k.getTahunTerbit(), k.getHarga()});
        }
        tblKomik.setModel(model);
    }

    private void loadDataPengarang() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Nama", "Negara", "Status"}, 0);
        List<Pengarang> list = em.createNamedQuery("Pengarang.findAll", Pengarang.class).getResultList();
        for (Pengarang p : list) {
            model.addRow(new Object[]{p.getPengarangId(), p.getNama(), p.getNegara(), p.getStatus()});
        }
        tblPengarang.setModel(model);
    }

    private void loadDataDetail() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Komik", "Pengarang", "Peran"}, 0);
        List<DetailKarya> list = em.createQuery("SELECT d FROM DetailKarya d", DetailKarya.class).getResultList();
        for (DetailKarya d : list) {
            model.addRow(new Object[]{d.getId(), d.getKomikId().getJudul(), d.getPengarangId().getNama(), d.getPeran()});
        }
        tblDetail.setModel(model);
    }

    private void aksiHapusKomik() {
        int row = tblKomik.getSelectedRow();
        if (row == -1) {
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Yakin hapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int id = Integer.parseInt(tblKomik.getValueAt(row, 0).toString());
            em.getTransaction().begin();
            em.remove(em.find(Komik.class, id));
            em.getTransaction().commit();
            loadDataKomik();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
        }
    }

    private void aksiHapusPengarang() {
        int row = tblPengarang.getSelectedRow();
        if (row == -1) {
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Yakin hapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int id = Integer.parseInt(tblPengarang.getValueAt(row, 0).toString());
            em.getTransaction().begin();
            em.remove(em.find(Pengarang.class, id));
            em.getTransaction().commit();
            loadDataPengarang();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
        }
    }

    private void aksiHapusDetail() {
        int row = tblDetail.getSelectedRow();
        if (row == -1) {
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Yakin hapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int id = Integer.parseInt(tblDetail.getValueAt(row, 0).toString());
            em.getTransaction().begin();
            em.remove(em.find(DetailKarya.class, id));
            em.getTransaction().commit();
            loadDataDetail();
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
        }
    }

    // METHOD CETAK (PLACEHOLDER UTK LOGIC JASPER REPORT NANTI)
    private void aksiCetakLaporan(String namaFileJasper) {
        // Nanti di sini kodingan JasperFillManager, JasperPrint, JasperViewer
        try {
            // 1. Tentukan Lokasi File Laporan
            // Kita gabungkan path folder dengan namaFile yang dikirim dari tombol
            File reportFile = new File("src/Report/" + namaFileJasper);

            // 2. Cek apakah file ada?
            if (!reportFile.exists()) {
                JOptionPane.showMessageDialog(this, "File laporan tidak ditemukan di:\n" + reportFile.getAbsolutePath());
                return;
            }

            // 3. Buat Koneksi Database (JDBC)
            String url = "jdbc:postgresql://localhost:5432/ProjekPBO"; // Sesuai DB kamu
            String user = "postgres";
            String pass = "170206"; // Sesuai password kamu

            Connection conn = DriverManager.getConnection(url, user, pass);

            // 4. Siapkan Parameter
            HashMap<String, Object> parameters = new HashMap<>();

            // 5. Isi Laporan
            JasperPrint print = JasperFillManager.fillReport(reportFile.getAbsolutePath(), parameters, conn);

            // 6. Tampilkan
            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setVisible(true);

        } catch (HeadlessException | SQLException | JRException e) {
            JOptionPane.showMessageDialog(this, "Gagal Mencetak: " + e.getMessage());
        }
    }

    private void aksiDownloadKomik() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Simpan Data Komik");
        fileChooser.setSelectedFile(new File("DataKomik.csv"));

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            // Pastikan ekstensi .csv
            if (!fileToSave.getAbsolutePath().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
            }

            try (PrintWriter pw = new PrintWriter(fileToSave)) {
                StringBuilder sb = new StringBuilder();

                // 1. Tulis Header (Judul Kolom)
                sb.append("ID;Judul;Genre;Tahun;Harga\n");

                // 2. Ambil Data dari Database
                List<Komik> list = em.createNamedQuery("Komik.findAll", Komik.class).getResultList();

                // 3. Tulis Baris Data
                for (Komik k : list) {
                    sb.append(k.getKomikId()).append(";");
                    sb.append(k.getJudul()).append(";");
                    sb.append(k.getGenre()).append(";");
                    sb.append(k.getTahunTerbit()).append(";");
                    sb.append(k.getHarga()).append("\n");
                }

                pw.write(sb.toString());
                JOptionPane.showMessageDialog(this, "Data berhasil diexport ke: " + fileToSave.getAbsolutePath());

            } catch (FileNotFoundException e) {
                JOptionPane.showMessageDialog(this, "Error membuat file: " + e.getMessage());
            }
        }
    }
// LOGIC UPLOAD CSV (CONTOH UNTUK TAB KOMIK)

    private void aksiUploadKomik() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Pilih File CSV Komik");

        int userSelection = fileChooser.showOpenDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToOpen = fileChooser.getSelectedFile();

            try (BufferedReader br = new BufferedReader(new FileReader(fileToOpen))) {
                String line;
                boolean isHeader = true;

                em.getTransaction().begin(); // Mulai Transaksi Database

                while ((line = br.readLine()) != null) {
                    // Lewati baris pertama kalau itu judul kolom
                    if (isHeader) {
                        isHeader = false;
                        continue;
                    }

                    // Pecah data berdasarkan koma
                    String[] data = line.split(";");

                    // Pastikan format data sesuai (Ada 4 kolom: Judul, Genre, Tahun, Harga)
                    // ID tidak perlu karena Auto Increment
                    if (data.length >= 4) {
                        Komik k = new Komik();
                        k.setJudul(data[0].trim());
                        k.setGenre(data[1].trim());
                        k.setTahunTerbit(Integer.valueOf(data[2].trim()));
                        k.setHarga(new BigDecimal(data[3].trim()));

                        em.persist(k); // Simpan ke memory
                    }
                }

                em.getTransaction().commit(); // Simpan permanen ke DB
                loadDataKomik(); // Refresh Tabel
                JOptionPane.showMessageDialog(this, "Upload Berhasil!");

            } catch (Exception e) {
                if (em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(this, "Gagal Upload: " + e.getMessage());
            }
        }
    }
    // LOGIC UPLOAD CSV PENGARANG

    private void aksiUploadPengarang() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Pilih File CSV Pengarang");

        int userSelection = fileChooser.showOpenDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToOpen = fileChooser.getSelectedFile();

            try (BufferedReader br = new BufferedReader(new FileReader(fileToOpen))) {
                String line;
                boolean isHeader = true;

                em.getTransaction().begin(); // Mulai Transaksi

                while ((line = br.readLine()) != null) {
                    // Lewati baris judul (Header)
                    if (isHeader) {
                        isHeader = false;
                        continue;
                    }

                    // Pecah data berdasarkan koma
                    String[] data = line.split(";");

                    // Validasi: Harus ada minimal 3 kolom (Nama, Negara, Status)
                    if (data.length >= 3) {
                        Pengarang p = new Pengarang();
                        p.setNama(data[0].trim());
                        p.setNegara(data[1].trim());
                        p.setStatus(data[2].trim());

                        em.persist(p); // Simpan ke memory
                    }
                }

                em.getTransaction().commit(); // Simpan permanen
                loadDataPengarang(); // Refresh Tabel
                JOptionPane.showMessageDialog(this, "Upload Data Pengarang Berhasil!");

            } catch (Exception e) {
                if (em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(this, "Gagal Upload: " + e.getMessage());
            }
        }
    }

    // LOGIC DOWNLOAD CSV PENGARANG
    private void aksiDownloadPengarang() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Simpan Data Pengarang");
        fileChooser.setSelectedFile(new File("DataPengarang.csv"));

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            // Tambahkan ekstensi .csv jika belum ada
            if (!fileToSave.getAbsolutePath().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
            }

            try (PrintWriter pw = new PrintWriter(fileToSave)) {
                StringBuilder sb = new StringBuilder();

                // 1. Tulis Header
                sb.append("ID;Nama;Negara;Status\n");

                // 2. Ambil Data dari Database
                List<Pengarang> list = em.createNamedQuery("Pengarang.findAll", Pengarang.class).getResultList();

                // 3. Tulis Baris Data
                for (Pengarang p : list) {
                    sb.append(p.getPengarangId()).append(";");
                    sb.append(p.getNama()).append(";");
                    sb.append(p.getNegara()).append(";");
                    sb.append(p.getStatus()).append("\n");
                }

                pw.write(sb.toString());
                JOptionPane.showMessageDialog(this, "Data Pengarang berhasil didownload!");

            } catch (FileNotFoundException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }

    // LOGIC DOWNLOAD CSV DETAIL KARYA
    private void aksiDownloadDetail() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Simpan Data Detail Karya");
        fileChooser.setSelectedFile(new File("DataDetailKarya.csv"));

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            if (!fileToSave.getAbsolutePath().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
            }

            try (PrintWriter pw = new PrintWriter(fileToSave)) {
                StringBuilder sb = new StringBuilder();

                // 1. Header
                sb.append("ID;Judul Komik;Nama Pengarang;Peran\n");

                // 2. Ambil Data
                // (Menggunakan Query SELECT d FROM DetailKarya d)
                List<DetailKarya> list = em.createQuery("SELECT d FROM DetailKarya d", DetailKarya.class).getResultList();

                // 3. Tulis Baris
                for (DetailKarya d : list) {
                    sb.append(d.getId()).append(";");
                    // Ambil Judul dari Relasi Komik
                    sb.append(d.getKomikId().getJudul()).append(";");
                    // Ambil Nama dari Relasi Pengarang
                    sb.append(d.getPengarangId().getNama()).append(";");
                    sb.append(d.getPeran()).append("\n");
                }

                pw.write(sb.toString());
                JOptionPane.showMessageDialog(this, "Data Detail Karya berhasil didownload!");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }

    // LOGIC UPLOAD CSV DETAIL KARYA
    private void aksiUploadDetail() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Pilih File CSV Detail Karya");

        int userSelection = fileChooser.showOpenDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToOpen = fileChooser.getSelectedFile();

            try (BufferedReader br = new BufferedReader(new FileReader(fileToOpen))) {
                String line;
                boolean isHeader = true;

                em.getTransaction().begin();

                while ((line = br.readLine()) != null) {
                    if (isHeader) {
                        isHeader = false;
                        continue;
                    }

                    String[] data = line.split(";");

                    // Validasi: Harus ada 3 kolom
                    if (data.length >= 3) {
                        String judulDiCsv = data[0].trim();
                        String namaDiCsv = data[1].trim();
                        String peranDiCsv = data[2].trim();

                        // TAHAP PENTING: MENCARI OBJECT BERDASARKAN NAMA
                        try {
                            // 1. Cari Komik berdasarkan Judul
                            Komik k = (Komik) em.createNamedQuery("Komik.findByJudul")
                                    .setParameter("judul", judulDiCsv)
                                    .getSingleResult();

                            // 2. Cari Pengarang berdasarkan Nama
                            // (Kita pakai Query Manual karena NamedQuery bawaan mungkin belum ada findByNama)
                            Pengarang p = em.createQuery("SELECT p FROM Pengarang p WHERE p.nama = :nama", Pengarang.class)
                                    .setParameter("nama", namaDiCsv)
                                    .getSingleResult();

                            // 3. Kalau ketemu dua-duanya, baru simpan
                            DetailKarya dk = new DetailKarya();
                            dk.setKomikId(k);       // Set Object Komik
                            dk.setPengarangId(p);   // Set Object Pengarang
                            dk.setPeran(peranDiCsv);

                            em.persist(dk);

                        } catch (NoResultException e) {
                            // Kalau Judul atau Nama tidak ditemukan di database, lewati baris ini
                            System.out.println("Data tidak ditemukan untuk: " + judulDiCsv + " / " + namaDiCsv);
                            continue;
                        }
                    }
                }

                em.getTransaction().commit();
                loadDataDetail(); // Refresh Tabel
                JOptionPane.showMessageDialog(this, "Upload Berhasil!");

            } catch (Exception e) {
                if (em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(this, "Gagal Upload: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
        }
        java.awt.EventQueue.invokeLater(() -> new MainPage().setVisible(true));
    }

    private JTabbedPane tabbedPane;

    // TAB 1 (KOMIK)
    private JTable tblKomik;
    private JButton btnAddKomik, btnEditKomik, btnDelKomik;
    private JButton btnUpKomik, btnDownKomik, btnPrintKomik; // Tombol Baru

    // TAB 2 (PENGARANG)
    private JTable tblPengarang;
    private JButton btnAddPengarang, btnEditPengarang, btnDelPengarang;
    private JButton btnUpPengarang, btnDownPengarang, btnPrintPengarang; // Tombol Baru

    // TAB 3 (DETAIL KARYA)
    private JTable tblDetail;
    private JButton btnAddDetail, btnEditDetail, btnDelDetail;
    private JButton btnUpDetail, btnDownDetail, btnPrintDetail; // Tombol Baru

    private JButton btnLogout;

    // PALET WARNA
    Color colorDark = new Color(102, 102, 102);
    Color colorBlue = new Color(153, 204, 255);
    Color colorText = new Color(102, 102, 102);

    // Warna Tombol Baru
    Color colorExcel = new Color(33, 115, 70);   // Hijau Excel
    Color colorDL = new Color(0, 99, 177);       // Biru Download
    Color colorPrint = new Color(102, 0, 102);   // Ungu Print
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

