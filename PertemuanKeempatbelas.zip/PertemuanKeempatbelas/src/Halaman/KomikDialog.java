/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Halaman;

import Entity.Komik;
import java.awt.*;
import java.math.BigDecimal;
import javax.persistence.*;
import javax.swing.*;

/**
 *
 * @author Husain
 */
public class KomikDialog extends javax.swing.JDialog {

    /**
     * Creates new form KomikDialog
     * @param parent
     * @param modal
     * @param em
     * @param komik
     */
    public KomikDialog(Frame parent, boolean modal, EntityManager em, Komik komik) {
        super(parent, modal);
        this.em = em;
        this.komikEdit = komik;
        initComponents1();
        isiForm(); // Jika Edit, isi textfield otomatis
    }

    private void initComponents1() {
        setSize(400, 500);
        setLocationRelativeTo(getParent());
        setLayout(null);
        getContentPane().setBackground(colorDark);

        String title = (komikEdit == null) ? "TAMBAH KOMIK" : "EDIT KOMIK";
        JLabel lblTitle = new JLabel("<html><span style='color:white'>" + title + "</span></html>");
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(0, 20, 400, 30);
        add(lblTitle);

        // INPUT FIELDS
        addLabel("Judul:", 30, 70);
        txtJudul = addTextField(30, 95);

        addLabel("Genre:", 30, 140);
        txtGenre = addTextField(30, 165);

        addLabel("Tahun Terbit:", 30, 210);
        txtTahun = addTextField(30, 235);

        addLabel("Harga:", 30, 280);
        txtHarga = addTextField(30, 305);

        // TOMBOL
        btnSimpan = new JButton("SIMPAN");
        btnSimpan.setBounds(30, 370, 160, 45);
        styleButton(btnSimpan, colorBlue);
        add(btnSimpan);

        btnBatal = new JButton("BATAL");
        btnBatal.setBounds(200, 370, 160, 45);
        styleButton(btnBatal, colorBlue);
        add(btnBatal);

        // EVENTS
        btnSimpan.addActionListener(e -> aksiSimpan());
        btnBatal.addActionListener(e -> dispose());
    }
    // Helper Styles

    private void addLabel(String text, int x, int y) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("Times New Roman", Font.BOLD, 14));
        l.setBounds(x, y, 200, 20);
        add(l);
    }

    private JTextField addTextField(int x, int y) {
        JTextField t = new JTextField();
        t.setBounds(x, y, 330, 35);
        t.setBackground(colorBlue);
        t.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        t.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        add(t);
        return t;
    }

    private void styleButton(JButton b, Color bg) {
        b.setBackground(bg);
        b.setFont(new Font("Times New Roman", Font.BOLD, 14));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void isiForm() {
        if (komikEdit != null) {
            txtJudul.setText(komikEdit.getJudul());
            txtGenre.setText(komikEdit.getGenre());
            txtTahun.setText(String.valueOf(komikEdit.getTahunTerbit()));
            txtHarga.setText(String.valueOf(komikEdit.getHarga()));
        }
    }

    private void aksiSimpan() {
        if (txtJudul.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Judul wajib diisi!");
            return;
        }

        try {
            em.getTransaction().begin();
            Komik k = (komikEdit == null) ? new Komik() : komikEdit;

            k.setJudul(txtJudul.getText());
            k.setGenre(txtGenre.getText());
            k.setTahunTerbit(Integer.valueOf(txtTahun.getText()));
            k.setHarga(new BigDecimal(txtHarga.getText()));

            if (komikEdit == null) {
                em.persist(k);
            } else {
                em.merge(k);
            }

            em.getTransaction().commit();
            isSuccess = true;
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
            dispose();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(this, "Gagal: " + e.getMessage());
        }
    }

    public boolean isSucceeded() {
        return isSuccess;
    }

    private JTextField txtJudul, txtGenre, txtTahun, txtHarga;
    private JButton btnSimpan, btnBatal;

    // Logic
    private EntityManager em;
    private Komik komikEdit = null; // Null = Insert, Isi = Edit
    private boolean isSuccess = false;

    // Tema Warna
    Color colorDark = new Color(102, 102, 102);
    Color colorBlue = new Color(153, 204, 255);
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
