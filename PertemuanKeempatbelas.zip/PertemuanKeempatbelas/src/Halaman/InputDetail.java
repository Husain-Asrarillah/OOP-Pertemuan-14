/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Halaman;

import Entity.*;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Frame;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.*;

/**
 *
 * @author Husain
 */
public class InputDetail extends javax.swing.JDialog {

    // =========================================
    // 1. DEKLARASI KOMPONEN GUI
    // =========================================
    private JComboBox<Komik> cbKomik;
    private JComboBox<Pengarang> cbPengarang;
    private JTextField txtPeran;
    private JButton btnSimpan;
    private JButton btnBatal;

    Color colorDarkGray = new Color(102, 102, 102);
    Color colorLightBlue = new Color(153, 204, 255);
    Color colorTextDark = new Color(102, 102, 102);
    Color colorWhite = Color.WHITE;

    // =========================================
    // 2. VARIABEL LOGIC & DATABASE
    // =========================================
    private final EntityManager em;
    private DetailKarya detailToEdit = null; // Null = Insert, Not Null = Edit
    private boolean isSuccess = false; // Status apakah berhasil simpan

    /**
     * Creates new form InputDetailFrom
     *
     * @param parent
     * @param modal
     * @param em
     * @param detail
     */
    public InputDetail(Frame parent, boolean modal, EntityManager em, DetailKarya detail) {
        super(parent, modal);
        this.em = em;
        this.detailToEdit = detail;

        initComponents1(); // Desain Tampilan
        isiComboBox();    // Isi Data ComboBox dari Database
        cekModeEdit();    // Cek apakah ini Edit atau Insert
    }

    private void initComponents1() {
        setSize(400, 480); // Ukuran sedikit lebih tinggi biar lega
        setLocationRelativeTo(getParent());
        setLayout(null);
        setResizable(false);

        // Set Background Gelap
        getContentPane().setBackground(colorDarkGray);

        // --- HEADER ---
        // Logic Judul: Kalau Edit muncul "EDIT", kalau baru muncul "TAMBAH"
        String actionText = (detailToEdit == null) ? "TAMBAH" : "EDIT";

        // HTML Styling: "TAMBAH" (Putih) + "DETAIL" (Biru)
        JLabel lblTitle = new JLabel("<html><span style='color:white'>" + actionText + "</span> <span style='color:#99CCFF'>DETAIL</span></html>");
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 26));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(0, 25, 400, 40);
        add(lblTitle);

        // --- INPUT 1: KOMIK ---
        JLabel lblKomik = new JLabel("Pilih Komik");
        styleLabel(lblKomik);
        lblKomik.setBounds(35, 80, 200, 20);
        add(lblKomik);

        cbKomik = new JComboBox<>();
        cbKomik.setBounds(35, 105, 315, 35);
        styleComboBox(cbKomik);
        add(cbKomik);

        // --- INPUT 2: PENGARANG ---
        JLabel lblPengarang = new JLabel("Pilih Pengarang");
        styleLabel(lblPengarang);
        lblPengarang.setBounds(35, 150, 200, 20);
        add(lblPengarang);

        cbPengarang = new JComboBox<>();
        cbPengarang.setBounds(35, 175, 315, 35);
        styleComboBox(cbPengarang);
        add(cbPengarang);

        // --- INPUT 3: PERAN ---
        JLabel lblPeran = new JLabel("Peran (Contoh: Illustrator)");
        styleLabel(lblPeran);
        lblPeran.setBounds(35, 220, 250, 20);
        add(lblPeran);

        txtPeran = new JTextField();
        txtPeran.setBounds(35, 245, 315, 35);
        styleTextField(txtPeran);
        add(txtPeran);

        // --- TOMBOL SIMPAN ---
        btnSimpan = new JButton("SIMPAN DATA");
        btnSimpan.setBounds(35, 310, 315, 45); // Tombol Lebar Full
        styleButton(btnSimpan);
        add(btnSimpan);

        // --- TOMBOL BATAL ---
        btnBatal = new JButton("BATAL");
        btnBatal.setBounds(35, 365, 315, 45); // Tombol Lebar Full
        styleButton(btnBatal);
        // Bikin tombol batal warnanya agak beda dikit (opsional), tapi ini disamakan biar rapi
        add(btnBatal);

        // EVENTS
        btnSimpan.addActionListener(e -> aksiSimpan());
        btnBatal.addActionListener(e -> dispose());
    }

    // --- METHOD HELPER UNTUK STYLING (Biar rapi) ---
    private void styleLabel(JLabel lbl) {
        lbl.setForeground(colorWhite);
        lbl.setFont(new Font("Times New Roman", Font.BOLD, 14));
    }

    private void styleTextField(JTextField txt) {
        txt.setBackground(colorLightBlue);
        txt.setForeground(colorTextDark); // Teks abu gelap biar kontras
        txt.setFont(new Font("Times New Roman", Font.BOLD, 14));
        txt.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Padding teks
        txt.setCaretColor(Color.BLACK);
    }

    private void styleComboBox(JComboBox cb) {
        cb.setBackground(colorLightBlue);
        cb.setForeground(colorTextDark);
        cb.setFont(new Font("Times New Roman", Font.BOLD, 14));
        // ComboBox agak tricky border-nya di Swing, tapi background color cukup membantu
        cb.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void styleButton(JButton btn) {
        btn.setBackground(colorLightBlue);
        btn.setForeground(colorTextDark);
        btn.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false); // Flat style
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    // Setting Jendela Dialog


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // =========================================
    // 6. LOGIKA PROGRAM (DATABASE)
    // =========================================
    // Mengisi ComboBox dengan Data dari Database
    private void isiComboBox() {
        try {
            // Ambil List Komik & Pengarang
            List<Komik> listKomik = em.createNamedQuery("Komik.findAll", Komik.class
            ).getResultList();
            List<Pengarang> listPengarang = em.createNamedQuery("Pengarang.findAll", Pengarang.class).getResultList();

            cbKomik.removeAllItems();
            cbPengarang.removeAllItems();

            // Loop insert ke ComboBox
            // Karena kamu sudah Override toString() di Entity, ini bakal muncul Nama/Judul
            for (Komik k : listKomik) {
                cbKomik.addItem(k);
            }
            for (Pengarang p : listPengarang) {
                cbPengarang.addItem(p);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal load data combo box: " + e.getMessage());
        }
    }

    // Cek apakah ini Insert atau Update
    private void cekModeEdit() {
        if (detailToEdit != null) {
            // JIKA EDIT: Isi form dengan data lama
            setTitle("Edit Data");
            txtPeran.setText(detailToEdit.getPeran());

            // Set ComboBox terpilih (Otomatis mencocokkan Object)
            // Pastikan method equals() di Entity Komik/Pengarang sudah ada (Generated NetBeans biasanya sudah ada)
            cbKomik.setSelectedItem(detailToEdit.getKomikId());
            cbPengarang.setSelectedItem(detailToEdit.getPengarangId());
        } else {
            // JIKA INSERT: Kosongkan / Default
            setTitle("Tambah Data");
        }
    }

    // Logika Simpan ke Database
    private void aksiSimpan() {
        // Validasi Input Kosong
        if (txtPeran.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Peran tidak boleh kosong!");
            return;
        }

        try {
            em.getTransaction().begin();

            DetailKarya d;

            if (detailToEdit == null) {
                // --- INSERT BARU ---
                d = new DetailKarya();
            } else {
                // --- UPDATE DATA LAMA ---
                d = detailToEdit;
            }

            // Set Data dari Form ke Entity
            // Casting (Komik) karena ComboBox isinya Object
            d.setKomikId((Komik) cbKomik.getSelectedItem());
            d.setPengarangId((Pengarang) cbPengarang.getSelectedItem());
            d.setPeran(txtPeran.getText());

            // Eksekusi JPA
            if (detailToEdit == null) {
                em.persist(d); // Simpan Baru
            } else {
                em.merge(d);   // Update
            }

            em.getTransaction().commit();

            // Beri tanda sukses & Tutup
            isSuccess = true;
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
            this.dispose();

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(this, "Gagal Simpan: " + e.getMessage());
        }
    }

    // Getter untuk dicek oleh MainPage
    public boolean isSucceeded() {
        return isSuccess;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
