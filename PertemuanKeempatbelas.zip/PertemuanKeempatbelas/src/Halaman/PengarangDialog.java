/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Halaman;

import Entity.Pengarang;
import java.awt.*;
import javax.persistence.*;
import javax.swing.*;

/**
 *
 * @author Husain
 */
public class PengarangDialog extends javax.swing.JDialog {

    /**
     * Creates new form PengarangDialog
     * @param parent
     * @param modal
     * @param em
     * @param p
     */
    public PengarangDialog(Frame parent, boolean modal, EntityManager em, Pengarang p) {
        super(parent, modal);
        this.em = em;
        this.pengarangEdit = p;
        initComponents1();
        isiForm();
    }

    private void initComponents1() {
        setSize(400, 450); // Lebih pendek dikit
        setLocationRelativeTo(getParent());
        setLayout(null);
        getContentPane().setBackground(colorDark);

        String title = (pengarangEdit == null) ? "TAMBAH PENGARANG" : "EDIT PENGARANG";
        JLabel lblTitle = new JLabel("<html><span style='color:white'>" + title + "</span></html>");
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(0, 20, 400, 30);
        add(lblTitle);

        // INPUT FIELDS
        addLabel("Nama Pengarang:", 30, 70);
        txtNama = addTextField(30, 95);

        addLabel("Negara Asal:", 30, 140);
        txtNegara = addTextField(30, 165);

        addLabel("Status (Aktif/Hiatus):", 30, 210);
        txtStatus = addTextField(30, 235);

        // TOMBOL
        btnSimpan = new JButton("SIMPAN");
        btnSimpan.setBounds(30, 320, 160, 45);
        styleButton(btnSimpan, colorBlue);
        add(btnSimpan);

        btnBatal = new JButton("BATAL");
        btnBatal.setBounds(200, 320, 160, 45);
        styleButton(btnBatal, colorBlue);
        add(btnBatal);

        btnSimpan.addActionListener(e -> aksiSimpan());
        btnBatal.addActionListener(e -> dispose());
    }

    // Helper Styles (Sama kayak Komik)
    private void addLabel(String text, int x, int y) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.WHITE);
        l.setFont(new Font("Times New Roman", Font.BOLD, 14));
        l.setBounds(x, y, 200, 20);
        add(l);
    }

    private JTextField addTextField(int x, int y) {
        JTextField t = new JTextField();
        t.setBounds(x, y, 330, 35);
        t.setBackground(colorBlue);
        t.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        t.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        add(t);
        return t;
    }

    private void styleButton(JButton b, Color bg) {
        b.setBackground(bg);
        b.setFont(new Font("Times New Roman", Font.BOLD, 14));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void isiForm() {
        if (pengarangEdit != null) {
            txtNama.setText(pengarangEdit.getNama());
            txtNegara.setText(pengarangEdit.getNegara());
            txtStatus.setText(pengarangEdit.getStatus());
        }
    }

    private void aksiSimpan() {
        if (txtNama.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama wajib diisi!");
            return;
        }
        try {
            em.getTransaction().begin();
            Pengarang p = (pengarangEdit == null) ? new Pengarang() : pengarangEdit;
            p.setNama(txtNama.getText());
            p.setNegara(txtNegara.getText());
            p.setStatus(txtStatus.getText());

            if (pengarangEdit == null) {
                em.persist(p);
            } else {
                em.merge(p);
            }

            em.getTransaction().commit();
            isSuccess = true;
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
            dispose();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        }
    }

    public boolean isSucceeded() {
        return isSuccess;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
private JTextField txtNama, txtNegara, txtStatus;
    private JButton btnSimpan, btnBatal;

    private EntityManager em;
    private Pengarang pengarangEdit = null;
    private boolean isSuccess = false;

    Color colorDark = new Color(102, 102, 102);
    Color colorBlue = new Color(153, 204, 255);
}
