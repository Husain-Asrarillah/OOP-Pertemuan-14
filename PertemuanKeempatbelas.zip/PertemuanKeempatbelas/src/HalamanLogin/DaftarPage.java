/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package HalamanLogin;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.persistence.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Husain
 */
public class DaftarPage extends javax.swing.JFrame {

    /**
     * Creates new form DaftarPage
     */
    public DaftarPage() {
        initComponents1();
        setLocationRelativeTo(null);

        // Default: Sembunyikan text field pertanyaan lain saat awal dijalankan
        tfPertanyaanLain.setVisible(false);
        pack(); // Sesuaikan ukuran window agar rapi
    }

    /**
     * Method inisialisasi komponen GUI
     */
    @SuppressWarnings("unchecked")
    private void initComponents1() {

        jPanel1 = new javax.swing.JPanel();

        // Header Text
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        // --- INPUT FIELDS ---
        // 1. Username
        jLabel1 = new javax.swing.JLabel();
        tfuser = new javax.swing.JTextField();

        // 2. Password
        jLabel3 = new javax.swing.JLabel();
        tfpass = new javax.swing.JPasswordField();

        // 3. Nama Lengkap
        lblNama = new javax.swing.JLabel();
        tfNama = new javax.swing.JTextField();

        // 4. Security Question
        lblTanya = new javax.swing.JLabel();
        cbPertanyaan = new javax.swing.JComboBox<>();

        // --- [BARU] Text Field untuk Pertanyaan Kustom ---
        tfPertanyaanLain = new javax.swing.JTextField();

        // 5. Security Answer
        lblJawab = new javax.swing.JLabel();
        tfJawaban = new javax.swing.JTextField();

        // Tombol & Link
        bsubmit = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        // Styling Panel Utama
        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        // Styling Header
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 30));
        jLabel2.setForeground(new java.awt.Color(153, 204, 255));
        jLabel2.setText("SIGN ");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 30));
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("UP");

        // Styling Username
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Username");

        tfuser.setBackground(new java.awt.Color(153, 204, 255));
        tfuser.setFont(new java.awt.Font("Times New Roman", 1, 12));
        tfuser.setForeground(new java.awt.Color(102, 102, 102));

        // Styling Password
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Password");

        tfpass.setBackground(new java.awt.Color(153, 204, 255));
        tfpass.setFont(new java.awt.Font("Times New Roman", 1, 12));
        tfpass.setForeground(new java.awt.Color(102, 102, 102));

        // Styling Nama Lengkap
        lblNama.setFont(new java.awt.Font("Times New Roman", 1, 14));
        lblNama.setForeground(new java.awt.Color(255, 255, 255));
        lblNama.setText("Nama Lengkap");

        tfNama.setBackground(new java.awt.Color(153, 204, 255));
        tfNama.setFont(new java.awt.Font("Times New Roman", 1, 12));
        tfNama.setForeground(new java.awt.Color(102, 102, 102));

        // Styling ComboBox Pertanyaan
        lblTanya.setFont(new java.awt.Font("Times New Roman", 1, 14));
        lblTanya.setForeground(new java.awt.Color(255, 255, 255));
        lblTanya.setText("Pertanyaan Keamanan (Untuk Reset Password)");

        cbPertanyaan.setBackground(new java.awt.Color(153, 204, 255));
        cbPertanyaan.setFont(new java.awt.Font("Times New Roman", 0, 12));
        cbPertanyaan.setForeground(new java.awt.Color(102, 102, 102));
        // [UBAH] Tambahkan "Pertanyaan Lain..." di opsi terakhir
        cbPertanyaan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{
            "Apa nama hewan peliharaan pertamamu?",
            "Siapa nama ibu kandungmu?",
            "Di kota mana kamu lahir?",
            "Apa makanan favoritmu?",
            "Apa nama sekolah SD-mu?",
            "Pertanyaan Lain..."
        }));

        // [BARU] LOGIC COMBOBOX CLICK
        cbPertanyaan.addActionListener((ActionEvent e) -> {
            String selected = cbPertanyaan.getSelectedItem().toString();
            if (selected.equals("Pertanyaan Lain...")) {
                tfPertanyaanLain.setVisible(true); // Munculkan
                tfPertanyaanLain.requestFocus();
            } else {
                tfPertanyaanLain.setVisible(false); // Sembunyikan
                tfPertanyaanLain.setText("");
            }
            pack(); // Resize frame otomatis agar layout tidak berantakan
        });

        // [BARU] Styling TextField Pertanyaan Lain (Awalnya hidden)
        tfPertanyaanLain.setBackground(new java.awt.Color(255, 255, 204)); // Warna beda dikit biar ngeh
        tfPertanyaanLain.setFont(new java.awt.Font("Times New Roman", 2, 12)); // Italic
        tfPertanyaanLain.setForeground(new java.awt.Color(102, 102, 102));
        tfPertanyaanLain.setText("Ketik pertanyaan Anda sendiri...");
        tfPertanyaanLain.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (tfPertanyaanLain.getText().equals("Ketik pertanyaan Anda sendiri...")) {
                    tfPertanyaanLain.setText("");
                    tfPertanyaanLain.setFont(new java.awt.Font("Times New Roman", 0, 12));
                }
            }
        });

        // Styling Jawaban
        lblJawab.setFont(new java.awt.Font("Times New Roman", 1, 14));
        lblJawab.setForeground(new java.awt.Color(255, 255, 255));
        lblJawab.setText("Jawaban");

        tfJawaban.setBackground(new java.awt.Color(153, 204, 255));
        tfJawaban.setFont(new java.awt.Font("Times New Roman", 1, 12));
        tfJawaban.setForeground(new java.awt.Color(102, 102, 102));

        // Styling Tombol Register
        bsubmit.setBackground(new java.awt.Color(153, 204, 255));
        bsubmit.setFont(new java.awt.Font("Times New Roman", 1, 18));
        bsubmit.setForeground(new java.awt.Color(102, 102, 102));
        bsubmit.setText("REGISTER");
        bsubmit.addActionListener(this::bsubmitActionPerformed);

        // Styling Link Login
        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Sudah punya akun? Login disini");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        // --- LAYOUT SETTING ---
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(lblJawab)
                                        .addComponent(lblTanya)
                                        .addComponent(lblNama)
                                        .addComponent(jLabel1)
                                        .addComponent(jLabel3)
                                        .addComponent(tfuser)
                                        .addComponent(tfpass)
                                        .addComponent(tfNama)
                                        .addComponent(cbPertanyaan, 0, 250, Short.MAX_VALUE)
                                        .addComponent(tfPertanyaanLain) // [BARU] Masukkan ke Layout
                                        .addComponent(tfJawaban)
                                        .addComponent(bsubmit, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE))
                                .addContainerGap(49, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4)
                                .addGap(100, 100, 100))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5)
                                .addGap(75, 75, 75))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel4))
                                .addGap(18, 18, 18)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfuser, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfpass, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(lblNama)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfNama, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(lblTanya)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbPertanyaan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED) // Jarak dikit
                                .addComponent(tfPertanyaanLain, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE) // [BARU] Posisi TextField
                                .addGap(10, 10, 10)
                                .addComponent(lblJawab)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfJawaban, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25)
                                .addComponent(bsubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel5)
                                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        private void bsubmitActionPerformed(java.awt.event.ActionEvent evt) {
        // 1. Persiapan Koneksi JPA
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PertemuanKeempatbelasPU");
        EntityManager em = emf.createEntityManager();

        // 2. Ambil Data dari Form
        String inputUser = tfuser.getText();
        String inputPass = new String(tfpass.getPassword());
        String inputNama = tfNama.getText();
        String inputJawab = tfJawaban.getText();

        // --- [BARU] LOGIKA MENGAMBIL PERTANYAAN ---
        String inputTanya = "";
        String pilihanCombo = cbPertanyaan.getSelectedItem().toString();

        if (pilihanCombo.equals("Pertanyaan Lain...")) {
            // Jika pilih custom, ambil dari text field
            inputTanya = tfPertanyaanLain.getText();
            // Validasi pertanyaan custom gak boleh kosong
            if (inputTanya.isEmpty() || inputTanya.equals("Ketik pertanyaan Anda sendiri...")) {
                JOptionPane.showMessageDialog(this, "Harap ketik pertanyaan kustom Anda!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } else {
            // Jika pilih standar, ambil dari combobox
            inputTanya = pilihanCombo;
        }
        // -------------------------------------------

        // 3. Validasi Form Kosong
        if (inputUser.isEmpty() || inputPass.isEmpty() || inputNama.isEmpty() || inputJawab.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Harap isi semua kolom!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 4. Proses Register ke Database
        try {
            // Cek Username Kembar
            Login userTerdaftar = em.find(Login.class, inputUser);

            if (userTerdaftar != null) {
                JOptionPane.showMessageDialog(this,
                        "Username '" + inputUser + "' sudah digunakan!\nSilakan pilih username lain.",
                        "Gagal Register",
                        JOptionPane.WARNING_MESSAGE);
                tfuser.requestFocus();
            } else {
                // Mulai Simpan
                em.getTransaction().begin();

                Login newUser = new Login();
                newUser.setUsername(inputUser);
                newUser.setPassword(inputPass);
                newUser.setFullName(inputNama);
                newUser.setSecurityQuestion(inputTanya); // Data pertanyaan yang sudah difilter tadi
                newUser.setSecurityAnswer(inputJawab);

                em.persist(newUser);
                em.getTransaction().commit();

                JOptionPane.showMessageDialog(this, "Registrasi Berhasil! Silakan Login.");

                // Pindah ke Form Login
                new LoginPage().setVisible(true);
                this.dispose();
            }

        } catch (HeadlessException e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(this, "Error Database: " + e.getMessage());
        } finally {
            em.close();
            emf.close();
        }
    }

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {
        new LoginPage().setVisible(true);
        this.dispose();
    }

//    public static void main(String args[]) {
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (Exception ex) {
//            java.util.logging.Logger.getLogger(DaftarPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//
//        java.awt.EventQueue.invokeLater(() -> {
//            new DaftarPage().setVisible(true);
//        });
//    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton bsubmit;
    private javax.swing.JComboBox<String> cbPertanyaan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel lblJawab;
    private javax.swing.JLabel lblNama;
    private javax.swing.JLabel lblTanya;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField tfJawaban;
    private javax.swing.JTextField tfNama;
    //[BARU] Variabel untuk text field pertanyaan kustom
    private javax.swing.JTextField tfPertanyaanLain;
    private javax.swing.JPasswordField tfpass;
    private javax.swing.JTextField tfuser;
    // End of variables declaration                   
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
