/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package HalamanLogin;

import javax.swing.*;
import java.awt.*;
import javax.persistence.*;

/**
 *
 * @author Husain
 */
public class ForgotPassw extends javax.swing.JFrame {

    private JTextField txtUsername;
    private JButton btnCari;

    private JTextField txtPertanyaan;
    private JTextField txtJawaban;
    private JButton btnVerifikasi;

    private JPasswordField txtPasswordBaru;
    private JButton btnSimpan;
    private JButton btnKembali;

    // Variabel Logic
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PertemuanKeempatbelasPU");
    EntityManager em = emf.createEntityManager();
    Login targetUser = null;

    /**
     * Creates new form ForgotPassw
     */
    public ForgotPassw() {
        initComponents1();
        initLogicState();
    }

    private void initComponents1() {
        setTitle("Reset Password");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null); // Layout Manual
        setLocationRelativeTo(null); // Tengah Layar
        setResizable(false);

        // --- PALET WARNA (Sesuai Tema Login) ---
        Color colorDarkGray = new Color(102, 102, 102);
        Color colorLightBlue = new Color(153, 204, 255);
        Color colorTextDark = new Color(102, 102, 102);
        Color colorWhite = Color.WHITE;

        // Set Background Utama Frame
        getContentPane().setBackground(colorDarkGray);

        // --- HEADER ---
        // Menggunakan HTML untuk pewarnaan teks ganda (LUPA = Putih, PASSWORD = Biru) biar keren
        JLabel lblTitle = new JLabel("<html><span style='color:white'>LUPA</span> <span style='color:#99CCFF'>PASSWORD</span></html>");
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 28));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(0, 20, 450, 40);
        add(lblTitle);

        JLabel lblSubtitle = new JLabel("Ikuti langkah berikut untuk mereset akun Anda");
        lblSubtitle.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        lblSubtitle.setForeground(colorWhite);
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitle.setBounds(0, 60, 450, 20);
        add(lblSubtitle);

        // --- STEP 1: CARI AKUN ---
        JLabel lblStep1 = new JLabel("1. Masukkan Username Anda");
        lblStep1.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblStep1.setForeground(colorWhite);
        lblStep1.setBounds(40, 100, 300, 20);
        add(lblStep1);

        txtUsername = new JTextField();
        txtUsername.setBounds(40, 125, 240, 30);
        applyFieldStyle(txtUsername, colorLightBlue, colorTextDark); // Custom Style Method
        add(txtUsername);

        btnCari = new JButton("Cari");
        btnCari.setBounds(290, 125, 100, 30);
        applyButtonStyle(btnCari, colorLightBlue, colorTextDark); // Custom Style Method
        add(btnCari);

        // --- STEP 2: PERTANYAAN KEAMANAN ---
        JLabel lblStep2 = new JLabel("2. Jawab Pertanyaan Keamanan");
        lblStep2.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblStep2.setForeground(colorWhite);
        lblStep2.setBounds(40, 175, 300, 20);
        add(lblStep2);

        JLabel lblQ = new JLabel("Pertanyaan:");
        lblQ.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        lblQ.setForeground(colorWhite);
        lblQ.setBounds(40, 200, 100, 20);
        add(lblQ);

        txtPertanyaan = new JTextField();
        txtPertanyaan.setBounds(40, 220, 350, 30);
        txtPertanyaan.setEditable(false); // Read Only
        applyFieldStyle(txtPertanyaan, new Color(200, 200, 200), colorTextDark); // Agak gelap dikit krn read-only
        add(txtPertanyaan);

        JLabel lblA = new JLabel("Jawaban Anda:");
        lblA.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        lblA.setForeground(colorWhite);
        lblA.setBounds(40, 260, 100, 20);
        add(lblA);

        txtJawaban = new JTextField();
        txtJawaban.setBounds(40, 280, 240, 30);
        applyFieldStyle(txtJawaban, colorLightBlue, colorTextDark);
        add(txtJawaban);

        btnVerifikasi = new JButton("Cek");
        btnVerifikasi.setBounds(290, 280, 100, 30);
        applyButtonStyle(btnVerifikasi, colorLightBlue, colorTextDark);
        add(btnVerifikasi);

        // --- STEP 3: RESET PASSWORD ---
        JLabel lblStep3 = new JLabel("3. Buat Password Baru");
        lblStep3.setFont(new Font("Times New Roman", Font.BOLD, 14));
        lblStep3.setForeground(colorWhite);
        lblStep3.setBounds(40, 330, 300, 20);
        add(lblStep3);

        txtPasswordBaru = new JPasswordField();
        txtPasswordBaru.setBounds(40, 355, 350, 30);
        applyFieldStyle(txtPasswordBaru, colorLightBlue, colorTextDark);
        add(txtPasswordBaru);

        // --- TOMBOL SIMPAN ---
        btnSimpan = new JButton("SIMPAN PASSWORD BARU");
        btnSimpan.setBounds(40, 400, 350, 40);
        applyButtonStyle(btnSimpan, colorLightBlue, colorTextDark);
        // Khusus tombol simpan font lebih besar
        btnSimpan.setFont(new Font("Times New Roman", Font.BOLD, 16));
        add(btnSimpan);

        // --- TOMBOL KEMBALI ---
        btnKembali = new JButton("Kembali ke Login");
        btnKembali.setBounds(40, 480, 350, 30);
        applyButtonStyle(btnKembali, colorLightBlue, colorTextDark);
        add(btnKembali);

        // =========================================
        // 3. EVENT LISTENERS (LOGIKA)
        // =========================================
        btnCari.addActionListener(e -> aksiCariUsername());
        btnVerifikasi.addActionListener(e -> aksiVerifikasiJawaban());
        btnSimpan.addActionListener(e -> aksiSimpanPassword());
        btnKembali.addActionListener(e -> {
            new LoginPage().setVisible(true);
            dispose();
        });
    }

    // --- HELPER METHODS FOR STYLING (Biar kodenya rapi) ---
    private void applyFieldStyle(JTextField field, Color bg, Color fg) {
        field.setBackground(bg);
        field.setForeground(fg);
        field.setFont(new Font("Times New Roman", Font.BOLD, 14));
        field.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Padding
    }

    private void applyButtonStyle(JButton btn, Color bg, Color fg) {
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFont(new Font("Times New Roman", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void initLogicState() {
        txtPertanyaan.setText("(Cari username dulu...)");
        txtJawaban.setEnabled(false);
        btnVerifikasi.setEnabled(false);
        txtPasswordBaru.setEnabled(false);
        btnSimpan.setEnabled(false);
    }

    private void aksiCariUsername() {
        String username = txtUsername.getText().trim();
        if (username.isEmpty()) {
            return;
        }

        try {
            targetUser = em.find(Login.class, username);
            if (targetUser != null) {
                txtPertanyaan.setText(targetUser.getSecurityQuestion());
                txtUsername.setEditable(false);
                btnCari.setEnabled(false);
                txtJawaban.setEnabled(true);
                btnVerifikasi.setEnabled(true);
                txtJawaban.requestFocus();
            } else {
                JOptionPane.showMessageDialog(this, "Username tidak ditemukan!");
            }
        } catch (HeadlessException e) {
        }
    }

    private void aksiVerifikasiJawaban() {
        String input = txtJawaban.getText().trim();
        String asli = targetUser.getSecurityAnswer();

        if (input.equalsIgnoreCase(asli)) {
            JOptionPane.showMessageDialog(this, "Jawaban Benar! Silakan isi password baru.");
            txtJawaban.setEnabled(false);
            btnVerifikasi.setEnabled(false);
            txtPasswordBaru.setEnabled(true);
            btnSimpan.setEnabled(true);
            txtPasswordBaru.requestFocus();
        } else {
            JOptionPane.showMessageDialog(this, "Jawaban Salah!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void aksiSimpanPassword() {
        String newPass = new String(txtPasswordBaru.getPassword());
        if (newPass.isEmpty()) {
            return;
        }

        try {
            em.getTransaction().begin();
            targetUser.setPassword(newPass);
            em.merge(targetUser);
            em.getTransaction().commit();

            JOptionPane.showMessageDialog(this, "Password berhasil diubah! Silakan Login.");
            new LoginPage().setVisible(true);
            this.dispose();
        } catch (HeadlessException e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(this, "Gagal update password.");
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
