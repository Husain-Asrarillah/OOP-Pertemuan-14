/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Husain
 */
@Entity
@Table(name = "pengarang")
@NamedQueries({
    @NamedQuery(name = "Pengarang.findAll", query = "SELECT p FROM Pengarang p"),
    @NamedQuery(name = "Pengarang.findByPengarangId", query = "SELECT p FROM Pengarang p WHERE p.pengarangId = :pengarangId"),
    @NamedQuery(name = "Pengarang.findByNama", query = "SELECT p FROM Pengarang p WHERE p.nama = :nama"),
    @NamedQuery(name = "Pengarang.findByNegara", query = "SELECT p FROM Pengarang p WHERE p.negara = :negara"),
    @NamedQuery(name = "Pengarang.findByStatus", query = "SELECT p FROM Pengarang p WHERE p.status = :status")})
public class Pengarang implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "pengarang_id")
    private Integer pengarangId;
    @Basic(optional = false)
    @Column(name = "nama")
    private String nama;
    @Column(name = "negara")
    private String negara;
    @Column(name = "status")
    private String status;
    @OneToMany(mappedBy = "pengarangId")
    private Collection<DetailKarya> detailKaryaCollection;

    public Pengarang() {
    }

    public Pengarang(Integer pengarangId) {
        this.pengarangId = pengarangId;
    }

    public Pengarang(Integer pengarangId, String nama) {
        this.pengarangId = pengarangId;
        this.nama = nama;
    }

    public Integer getPengarangId() {
        return pengarangId;
    }

    public void setPengarangId(Integer pengarangId) {
        this.pengarangId = pengarangId;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNegara() {
        return negara;
    }

    public void setNegara(String negara) {
        this.negara = negara;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Collection<DetailKarya> getDetailKaryaCollection() {
        return detailKaryaCollection;
    }

    public void setDetailKaryaCollection(Collection<DetailKarya> detailKaryaCollection) {
        this.detailKaryaCollection = detailKaryaCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pengarangId != null ? pengarangId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pengarang)) {
            return false;
        }
        Pengarang other = (Pengarang) object;
        if ((this.pengarangId == null && other.pengarangId != null) || (this.pengarangId != null && !this.pengarangId.equals(other.pengarangId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.nama; // Agar ComboBox menampilkan Nama Pengarang

    }
}
    