/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Husain
 */
@Entity
@Table(name = "komik")
@NamedQueries({
    @NamedQuery(name = "Komik.findAll", query = "SELECT k FROM Komik k"),
    @NamedQuery(name = "Komik.findByKomikId", query = "SELECT k FROM Komik k WHERE k.komikId = :komikId"),
    @NamedQuery(name = "Komik.findByJudul", query = "SELECT k FROM Komik k WHERE k.judul = :judul"),
    @NamedQuery(name = "Komik.findByGenre", query = "SELECT k FROM Komik k WHERE k.genre = :genre"),
    @NamedQuery(name = "Komik.findByTahunTerbit", query = "SELECT k FROM Komik k WHERE k.tahunTerbit = :tahunTerbit"),
    @NamedQuery(name = "Komik.findByHarga", query = "SELECT k FROM Komik k WHERE k.harga = :harga")})
public class Komik implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "komik_id")
    private Integer komikId;
    @Basic(optional = false)
    @Column(name = "judul")
    private String judul;
    @Column(name = "genre")
    private String genre;
    @Column(name = "tahun_terbit")
    private Integer tahunTerbit;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "harga")
    private BigDecimal harga;
    @OneToMany(mappedBy = "komikId")
    private Collection<DetailKarya> detailKaryaCollection;

    public Komik() {
    }

    public Komik(Integer komikId) {
        this.komikId = komikId;
    }

    public Komik(Integer komikId, String judul) {
        this.komikId = komikId;
        this.judul = judul;
    }

    public Integer getKomikId() {
        return komikId;
    }

    public void setKomikId(Integer komikId) {
        this.komikId = komikId;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Integer getTahunTerbit() {
        return tahunTerbit;
    }

    public void setTahunTerbit(Integer tahunTerbit) {
        this.tahunTerbit = tahunTerbit;
    }

    public BigDecimal getHarga() {
        return harga;
    }

    public void setHarga(BigDecimal harga) {
        this.harga = harga;
    }

    public Collection<DetailKarya> getDetailKaryaCollection() {
        return detailKaryaCollection;
    }

    public void setDetailKaryaCollection(Collection<DetailKarya> detailKaryaCollection) {
        this.detailKaryaCollection = detailKaryaCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (komikId != null ? komikId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Komik)) {
            return false;
        }
        Komik other = (Komik) object;
        if ((this.komikId == null && other.komikId != null) || (this.komikId != null && !this.komikId.equals(other.komikId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.judul; // <-- UBAH INI! Agar ComboBox menampilkan Judul
    }

}
